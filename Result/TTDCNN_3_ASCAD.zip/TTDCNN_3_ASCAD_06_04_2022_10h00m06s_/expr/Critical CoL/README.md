#Instruction on the Critical CoL obtained.
- lst_not_remove_threshold_1_rerun.csv consists of the list of Critical CoLs<br>

- While sequentially_removed_lst_threshold_1_rerun.csv is the list of order in which the Algorithm 1 remove.

- sequential_threshold_1_rerun.csv is DNF_{in} of Algorithm 1 (at the end)
sequential_threshold_1_unwanted_rerun.csv is disjuncts with CoL in Lst_{out} of Algorithm 1 (at the end).
